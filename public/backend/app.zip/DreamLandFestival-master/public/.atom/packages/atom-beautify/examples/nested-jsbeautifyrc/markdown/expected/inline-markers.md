An example of __bold__ and _italics_.

Another example of __bold__ and _italics_.
