
1.1.2 / 2015-05-05
==================

  * using a config schema now
  * updating amp

1.1.1 / 2015-04-20
==================

  * using the new getPaths function

1.1.0 / 2015-04-15
==================

  * removing deprecated calls

1.0.0 / 2015-01-20
==================

  * total rewriting
  * updating the README to match the new rewrite
  * removing static preview image
  * adding LICENSE
  * adding .editorconfig

0.5.1 / 2014-05-22
==================

 * fixing issue #7

0.5.0 / 2014-05-14
==================

 * adding support for windows and linux

0.4.4 / 2014-04-30
==================

 * fix for the line indicator bug

0.4.3 / 2014-04-08
==================

 * adding line support for warnings

0.4.2 / 2014-03-17
==================

 * adding support for warnings

0.4.0 / 2014-03-17
==================

 * adding a little bug *(the good kind)*
 * adding the option to hide on no errors
 * adding the option to use fold mode by default
 * adding line indicators
 * updating [atom-message-panel](https://github.com/tcarlsen/atom-message-panel) to 0.3.0

0.3.3 / 2014-03-13
==================

 * now using [loophole](https://github.com/atom/loophole) to allow CCSLint to use eval

0.3.2 / 2014-03-11
==================

 * changed the keymap to `cmd-alt-l`
 * now using [atom-keymap-plus](https://github.com/tcarlsen/atom-keymap-plus)

0.3.0 / 2014-03-11
==================

 * adding change log fie
 * adding validateOnSave and validateOnChange options
 * file split up for easier overview
 * now using [atom-message-panel](https://github.com/tcarlsen/atom-message-panel)
